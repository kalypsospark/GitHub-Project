var topText = "what are they doing...";

function preload() {
  
  background = loadImage("garregMach.jpeg");
  
  shart = loadImage("shadowheart.jpeg");
  
  guy = loadImage("lilguy.png");
  
}

function setup() {
  
  createCanvas(1200, 675);
  
  colorMode(RGB);
  
  textFont("Courier New");
  fill(80,20,80);
  stroke(255);
  strokeWeight(2);
  textSize(80);
  
}

function draw() {
 
  image(background,0,0);
  
  image(shart, mouseX, mouseY);
  
  image(guy, (mouseX+100), 100, mouseX*1.5, mouseY*1.5);
  
  //
  textAlign(CENTER,TOP);
  text(topText, 0, 30, 1200, 100);
  

}