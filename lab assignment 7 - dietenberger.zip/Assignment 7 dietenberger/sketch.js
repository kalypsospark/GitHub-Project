function setup() {
  createCanvas(1000, 500);
  
  var highscoreBasePoints = 1500
  
  var leaderboardScore = calculateHighscore(highscoreBasePoints);
  
  print(leaderboardScore);
  
  
}

function calculateHighscore(s) {
  
  
  var newScore = s * 3.4;
  // I was thinking this was like a leaderboard calculator If that makes sense
  
  return newScore;
  
}


function draw() {
  
  background(0);
  
  push();
  
  scale(0.5);      
  for (var x=-30; x < 2*width + 130; x+= 130) { alien1(x,50)
       }     
  
  angleMode(DEGREES);
  rotate(30);                                      
  alien1(300,20);  
  
  scale(0.75);
  angleMode(DEGREES);
  rotate(12);                                      
  alien1(1500,-50);
  
  pop();
  
  
  colorMode(RGB,255);
  fill(255,50,50);
  textAlign(CENTER);
  textSize(130);
  textStyle(BOLD);
  textFont('Verdana');
  text('GAME OVER',500,300);
  
  
}


function alien1(x, y) {
  
  push(); 
  
  translate(x,y);
  
  noStroke();
  fill(255);
  
  square(20,0,10);
  square(30,10,10);
  square(20,20,10);
  square(30,20,10);
  square(40,20,10);
  square(50,20,10);
  square(60,20,10);
  square(70,20,10);
  square(80,20,10);
  square(70,10,10);
  square(80,0,10);
  //
  square(10,30,10);
  square(20,30,10);
  square(40,30,10);
  square(50,30,10);
  square(60,30,10);
  square(80,30,10);
  square(90,30,10);
  //
  square(0,40,10);
  square(10,40,10);
  square(20,40,10);
  square(30,40,10);
  square(40,40,10);
  square(50,40,10);
  square(60,40,10);
  square(70,40,10);
  square(80,40,10);
  square(90,40,10);
  square(100,40,10);
  //
  square(0,50,10);
  square(0,60,10);
  //
  square(20,50,10);
  square(20,60,10);
  //
  square(100,50,10);
  square(100,60,10);
  //
  square(80,50,10);
  square(80,60,10);
  //
  square(30,50,10);
  square(40,50,10);
  square(50,50,10);
  square(60,50,10);
  square(70,50,10);
  //
  square(30,70,10);
  square(40,70,10);
  square(60,70,10);
  square(70,70,10);
  
  pop();
  
}